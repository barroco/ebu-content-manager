﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace Kayak.Tests
{
    class Config
    {
        public static int Port = 3457;
    }
}
