﻿using System;
using System.Diagnostics;

namespace Kayak.Http
{
    public static partial class Extensions
    {
    }
}
